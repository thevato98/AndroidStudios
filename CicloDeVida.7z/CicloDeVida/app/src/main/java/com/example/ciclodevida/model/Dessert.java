package com.example.ciclodevida.model;

data class Dessert {
}
